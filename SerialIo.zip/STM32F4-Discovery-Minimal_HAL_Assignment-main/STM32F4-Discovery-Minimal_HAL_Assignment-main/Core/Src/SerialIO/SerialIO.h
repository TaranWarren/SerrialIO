
/*******************************************************************************
 * @file: serialio.h
 * @author: Taran Warren
 * @version: 1.0
 * @date: 11/02/2025
 * @brief: Initialise and implement functions for IO over UART
 *
 * using the RS232 serial port on the DM-STF-4BB
 * expansion board.
 *
 * A source file using these utilities to support stdio must also include:
 * @code <stdio.h>
 * in addition to this header.
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2024 Staffordshire University
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */

/* Includes ------------------------------------------------------------------*/
#include "serialio.h"


/* Global variables ----------------------------------------------------------*/
static UART_HandleTypeDef serialIO;


